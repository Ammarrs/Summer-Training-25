from typing import Literal, TypedDict

Difficulty = Literal["easy", "medium", "hard"]
CourseType = Literal["theoretical", "practical"]
Structure = Literal["chapter", "topic"]

class Course(TypedDict):
    name: str
    type: CourseType
    structure: Structure
    difficulty: Difficulty

class ScheduleItem(TypedDict):
    day: str
    time: str
    course: str
    part: str

class Preferences(TypedDict):
    study_speed: Literal["slow", "average", "fast"]
    memorization_vs_understanding: int
    self_rating: int
    session_style: Literal["continuous", "interrupted"]