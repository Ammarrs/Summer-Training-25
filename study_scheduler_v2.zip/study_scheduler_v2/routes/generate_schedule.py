from flask import Blueprint, request, jsonify
from utils.schedule_generator import generate_schedule

schedule_bp = Blueprint('schedule', __name__)

@schedule_bp.route('/generate-schedule', methods=['POST'])
def generate_schedule_route():
    data = request.get_json()
    try:
        schedule = generate_schedule(data)
        return jsonify(schedule), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400