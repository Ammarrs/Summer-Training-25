from typing import Dict, List, Any
from models.types import Course, ScheduleItem, Preferences
from utils.helpers import difficultyScore, capitalize, adjust_course_blocks

def generate_schedule(data: Dict[str, Any]) -> List[ScheduleItem]:
    courses = data['courses']
    availability = data['availability']
    preferences = data['preferences']
    max_blocks_per_day = data.get('max_study_blocks_per_day', 6)

    allSlots = []
    for day, times in availability.items():
        daily_limit = min(len(times), max_blocks_per_day)
        for i in range(daily_limit):
            allSlots.append({'day': day, 'time': times[i]})

    courseBlocks = adjust_course_blocks(courses, preferences)

    sortedCourses = sorted(courses, key=lambda c: courseBlocks[c['name']], reverse=True)

    schedule = []
    slotIndex = 0
    for course in sortedCourses:
        blocks = courseBlocks[course['name']]
        for i in range(blocks):
            if slotIndex >= len(allSlots):
                break
            slot = allSlots[slotIndex]
            part = f"{capitalize(course['structure'])} {i + 1}"
            schedule.append({
                "day": slot['day'],
                "time": slot['time'],
                "course": course['name'],
                "part": part
            })
            slotIndex += 1

    if slotIndex < sum(courseBlocks.values()):
        raise ValueError("Not enough slots to accommodate the full schedule.")

    return schedule