from typing import Dict
from models.types import Difficulty, Course, Preferences

difficultyScore: Dict[str, int] = {
    "easy": 1,
    "medium": 2,
    "hard": 3
}

def capitalize(s: str) -> str:
    return s[0].upper() + s[1:]

def adjust_course_blocks(courses, preferences: Preferences) -> Dict[str, int]:
    study_speed_multiplier = {
        "slow": 1.5,
        "average": 1.0,
        "fast": 0.8
    }

    blocks = {}
    speed = preferences.get("study_speed", "average")
    mem_understand = preferences.get("memorization_vs_understanding", 5)
    rating = preferences.get("self_rating", 3)

    for course in courses:
        base = difficultyScore[course['difficulty']] * 4
        adjusted = base * study_speed_multiplier.get(speed, 1.0)

        if course['type'] == 'theoretical' and mem_understand > 5:
            adjusted *= 1.1
        elif course['type'] == 'practical' and mem_understand < 5:
            adjusted *= 1.1

        adjusted *= 1 + (3 - rating) * 0.05
        blocks[course['name']] = round(adjusted)

    return blocks